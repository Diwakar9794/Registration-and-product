

<?php $__env->startSection('custome-js'); ?>
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="text-center">
         
            <h1 class="text-success">Awesome !</h1>
            <p>Login Successfull</p>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\AaraTech\resources\views/success.blade.php ENDPATH**/ ?>