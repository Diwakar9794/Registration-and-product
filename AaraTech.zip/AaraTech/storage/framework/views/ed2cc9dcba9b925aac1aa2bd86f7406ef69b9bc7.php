<?php $__env->startSection('custome-js'); ?>
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="signup-form">
    <div class="cotainer">
        <div class="row justify-content-center">

            <div class="col-md-8">
                <a href="<?php echo e(url('registration')); ?>" class="btn btn-primary">Registration + </a>
                <a href="<?php echo e(url('login')); ?>" class="btn btn-success">Login + </a>

                <span class="msg"></span>
                <table class="table ">
                    <th>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Contact</td>
                        <td>Address</td>
                    </th>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->id); ?></td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->contact); ?></td>
                            <td><?php echo e($value->address); ?></td>
                            <td><button value="<?php echo e($value->id); ?>" class="btn btn-danger delete">Delete</button></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\AaraTech\resources\views/welcome.blade.php ENDPATH**/ ?>