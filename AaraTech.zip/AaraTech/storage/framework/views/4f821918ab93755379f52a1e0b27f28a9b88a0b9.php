

<?php $__env->startSection('custome-js'); ?>
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="signup-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-6">
                    
                   
                    <table class="table">
                         <th>
                            <!-- <td>ID</td> -->
                            <td>Name</td>
                            <td>Price</td>
                            <td>Category</td>
                            <td>Manufacturer</td>
                        </th>

                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->id); ?></td>
                            <td><?php echo e($value->pname); ?></td>
                            <td><?php echo e($value->price); ?></td>
                            <td><?php echo e($value->category); ?></td>
                            <td><?php echo e($value->manufacturer); ?></td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(url('/cart')); ?>?Srno=<?php echo $value['id']; ?>&product=<?php echo $value['pname']; ?> &price=<?php echo $value['price']; ?>">BUY NOW</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </table>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel project\AaraTech\resources\views/productView.blade.php ENDPATH**/ ?>