@extends('dashboard')

@section('custome-js')
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
@endsection

@section('content')
<main class="signup-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-6">
                    
                   
                    <table class="table">
                         <th>
                            <!-- <td>ID</td> -->
                            <td>Name</td>
                            <td>Price</td>
                            <td>Category</td>
                            <td>Manufacturer</td>
                        </th>

                        @foreach($result as $value)
                        <tr>
                            <td>{{ $value->id }}</td>
                            <td>{{ $value->pname}}</td>
                            <td>{{ $value->price}}</td>
                            <td>{{ $value->category}}</td>
                            <td>{{ $value->manufacturer }}</td>
                            <td>
                                <a class="btn btn-primary" href="{{url('/cart')}}?Srno=<?php echo $value['id']; ?>&product=<?php echo $value['pname']; ?> &price=<?php echo $value['price']; ?>">BUY NOW</a>
                            </td>
                        </tr>
                        @endforeach    
                    </table>

            </div>
        </div>
    </div>
</main>
@endsection