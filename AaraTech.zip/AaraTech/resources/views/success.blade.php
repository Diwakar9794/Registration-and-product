@extends('dashboard')

@section('custome-js')
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
@endsection

@section('content')
        <div class="text-center">
         
            <h1 class="text-success">Awesome !</h1>
            <p>Login Successfull</p>
        </div>
@endsection