<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Registration;
use DB;
class customeController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function welcome()
    {
        return view('registration');
    }

    public function registration()
    {
       


        if(empty($_POST['name']))
        {
            echo "name";
        }
        else if(empty($_POST['email']))
        {
            echo "Email";
        }
        else if(empty($_POST['pass']))
        {
            echo "password";
        }
        else if(empty($_POST['contact']))
        {
            echo "contact";
        }
        else if(empty($_POST['address']))
        {   
            echo "address";
        }
        else
        {
                $name = $_POST['name'];
                $email = $_POST['email'];
                $password = $_POST['pass'];
                $contact = $_POST['contact'];
                $address = $_POST['address'];

                 if (!filter_var($email, FILTER_VALIDATE_EMAIL))
                {
                    echo  "Invalid email format";
                }
                else if(!preg_match('/^[0-9]{'.'8'.','.'12'.'}\z/', $contact))
                {
                    echo "Invalid cantact number";
                }
                else
                {
                      $check=DB::select("SELECT email FROM registrations where email='$email'");

                   if($check)
                   {
                    echo"Email Id is already exists";
                   }
                   else
                   {

                    $insert = new Registration();

                    $insert->name = $name;
                    $insert->email = $email; 
                    $insert->password = $password; 
                    $insert->contact = $contact; 
                    $insert->address = $address;
                    $r= $insert->save();
                      if($r)
                        {
                            echo "success";
                        }
                        
                   }
                  
                }
            }
    }


    public $data;
    public function display()
    {
        $data = Registration::all();
        return view("welcome",array("result"=>$data));
    }


    public function deleteData()
    {
        $id =  $_POST['id'];

        $check = Registration::where('id', $id)->firstorfail()->delete();

        echo $check;
    }


    public function loginpPage()
    {
        return view("login"); 
    }


    public function loginData()
    {
        $email =  $_POST['email'];
        $password =$_POST['pass'];

        $this->data = Registration::where("email",$email)->where("password",$password)->get();

        // echo count($this->data);
        if(count($this->data) != 0)
        {
            echo "found";  
         
        }
        else
        {
            echo "not found";
        }


    }
}
