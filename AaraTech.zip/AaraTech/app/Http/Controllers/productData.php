<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
class productData extends Controller
{
     public $data;
    public function index(){

        $this->data = Product::get();
        return view("productView",array("result"=>$this->data));
    }

    public function cartData()
    {
       if (isset($_REQUEST['Srno'])) {

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = 1;
            $_SESSION['session_items'][] = array($_GET['Srno'], $_GET['product'], $_GET['price']);
        } else {
            ++$_SESSION['cart'];
            $_SESSION['session_items'][] = array($_GET['Srno'], $_GET['product'], $_GET['price']);
        }
    }
    
    echo "<pre>";
    print_r($_SESSION);
        
    }
}
