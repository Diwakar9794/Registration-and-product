$(document).ready(function(){

	//registration 

	$(".registration").on("submit",function(e){
		e.preventDefault();

		
				$.ajaxSetup({
					headers :{
						'X-CSRF-TOKEN': $("body").attr("token")
					}
				});

				$.ajax({
					type:"post",
					url:"/registr",
					data:{
						"name": $("#name").val(),
						"email": $("#email_address").val(),

						"pass": $("#password").val(),
						"contact": $("#contact").val(),
						"address": $("#address").val(),

					},
					success:function(result)
					{
						

						if($.trim(result) == "name")
						{
							$(".nameErr").html("Name is required");
							setTimeout(function(){
		                                $(".nameErr").html("");
		                            },5000);
						}
						else if($.trim(result) == "Email")
						{
							$(".emailErr").html("Email is required");
							setTimeout(function(){
		                                $(".emailErr").html("");
		                            },5000);
						}
						else if($.trim(result) == "password")
						{
							$(".passErr").html("Password is required");
							setTimeout(function(){
		                                $(".passErr").html("");
		                            },5000);
						}
						else if($.trim(result) == "contact")
						{
							$(".contactErr").html("Contact is required");
							setTimeout(function(){
		                                $(".contactErr").html("");
		                            },5000);
						}
						else if($.trim(result) == "address")
						{
							$(".addErr").html("Address is required");
							setTimeout(function(){
		                                $(".addErr").html("");
		                            },5000);
						}
						else if($.trim(result) == "Invalid email format")
						{
							$(".emailErr").html("Invalid email format");
							setTimeout(function(){
		                                $(".emailErr").html("");
		                            },5000);

						}
						else if($.trim(result) == "Invalid cantact number")
						{
							$(".contactErr").html("Invalid cantact number");
							setTimeout(function(){
		                                $(".contactErr").html("");
		                            },5000);

						}
						else if($.trim(result) == "success")
						{
							window.location.href='/';
						} 	
						else
						{
							alert(result);
						}	
					

					}
				});	

	});


	// delete record
	$(".delete").on("click",function(){
		

			$.ajaxSetup({
					headers :{
						'X-CSRF-TOKEN': $("body").attr("token")
					}
				});

			$.ajax({
				type:"POST",
				url:"/delete",
				data:{
					id: $(this).val()
				},
				success:function(result)
				{
					if($.trim(result) =='1')
					{
						$(".msg").html("Record Delete Successfull");
							setTimeout(function(){
		                                $(".msg").html("");
		                                location.reload();
		                            },3000);

					}
					else
					{
						alert(result);
					}
				}
			});

	});


	// login

	$(".login").on("submit",function(e){
		e.preventDefault();

		$.ajaxSetup({
					headers :{
						'X-CSRF-TOKEN': $("body").attr("token")
					}
				});

			$.ajax({
				type:"POST",
				url:"/loginData",
				data:{
					email: $("#email").val(),
					pass : $("#password").val()

				},
				success:function(result)
				{
					if($.trim(result) == 'found')
					{
						window.location.href='/success';
					}
					else if($.trim(result) == 'not found')
					{
						$(".msg").html("Email or password is incorrect");
							setTimeout(function(){
		                                $(".msg").html("");
		                                location.reload();
		                            },3000);

					}
				}
			});
	});	
});